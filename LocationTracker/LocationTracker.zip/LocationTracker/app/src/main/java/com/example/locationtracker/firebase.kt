package com.example.locationtracker

import com.google.android.gms.maps.model.LatLng

class firebaseDb {

    companion object fireBaseDB{

        fun addLoc(location : LatLng){}

    }

}