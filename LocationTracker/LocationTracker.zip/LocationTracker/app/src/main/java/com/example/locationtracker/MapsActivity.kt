package com.example.locationtracker

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var locationManager: LocationManager
    private lateinit var locationListener: LocationListener
    var locList = ArrayList<LatLng>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {

        mMap = googleMap

        var userLocation:LatLng ?= null

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        locationListener = object:LocationListener{
            override fun onLocationChanged(location: Location?) {
                if (location != null) {
                    userLocation = LatLng(location.latitude,location.longitude)
                    firebaseDb.addLoc(userLocation!!)
                    locList.add(userLocation!!)
                    mMap.clear()
                    mMap.addMarker(MarkerOptions().position(userLocation!!).title("Current Location"))
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom( userLocation , 15f ))
                    setPolyLines()

                }
            }
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
            }
            override fun onProviderEnabled(provider: String?) {
            }
            override fun onProviderDisabled(provider: String?) {
            }
        }

//        if(ContextCompat.checkSelfPermission(Manifest.permission))
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),1)
        }else {

            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1,1f,locationListener)
            var lastLoc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if(lastLoc!=null){
                val lastLocation = LatLng(lastLoc.latitude,lastLoc.longitude)
                locList.add(lastLocation)
                mMap.clear()
                mMap.addMarker(MarkerOptions().position(lastLocation).title("YOUR LOCATION"))
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lastLocation,18f))
            }else{
//                Toast.makeText(applicationContext,"Unable to get Location",Toast.LENGTH_SHORT).show()
                //Move Camera to Ahmedabad
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(23.02,72.57),12f))
            }

        }



    }

    override fun onResume() {



        super.onResume()
    }

    fun setPolyLines() {

        if (!locList.isEmpty()) {
            var polyLineOptions = PolylineOptions();
            polyLineOptions.addAll(locList);
            polyLineOptions.width(5f);
            polyLineOptions.color(Color.BLUE);
            mMap.addPolyline(polyLineOptions);
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if(requestCode == 1){
            if(grantResults.size>0){
                if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                    locationManager!!.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,2,2f,locationListener)
                }
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }


}
